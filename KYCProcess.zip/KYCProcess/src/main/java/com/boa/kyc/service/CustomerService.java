package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.model.Customer;
import com.boa.kyc.repo.CustomerRepo;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepo customerRepo;

	public Customer addCustomer(Customer customer) {
		try {
			return customerRepo.save(customer);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}

	public Customer getCustomerById(int id) {
		return customerRepo.findById(id).orElse(null);
	}

	public List<Customer> getCustomerByName(String fname) {
		return customerRepo.findByName(fname);
	}

}

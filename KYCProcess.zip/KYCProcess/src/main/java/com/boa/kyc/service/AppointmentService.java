package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.model.Appointment;
import com.boa.kyc.repo.AppointmentRepo;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepo appointmentRepo;

	public Appointment saveAppointement(Appointment appoinment) {
		return appointmentRepo.save(appoinment);
	}

	public List<Appointment> getAllAppointments() {
		return appointmentRepo.findAll();
	}
}

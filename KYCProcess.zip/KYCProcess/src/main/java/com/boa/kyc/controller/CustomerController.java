package com.boa.kyc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.model.Customer;
import com.boa.kyc.service.CustomerService;

@RestController
@RequestMapping("/api")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@PostMapping("/save")
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) {
		return ResponseEntity.ok(customerService.addCustomer(customer));
	}

	@GetMapping("/getAllCustomers")
	public ResponseEntity<List<Customer>> getAllCustomers() {
		return ResponseEntity.ok(customerService.getAllCustomers());
	}

	@GetMapping("/getCustomerById/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable("id") int id) {
		return ResponseEntity.ok(customerService.getCustomerById(id));
	}

	@GetMapping("/getCustomerByName/{name}")
	public ResponseEntity<List<Customer>> getCustomerByName(@PathVariable("name") String name) {
		return ResponseEntity.ok(customerService.getCustomerByName(name));
	}

	@PutMapping("/updateCustomer")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer) {
		System.out.println(customer);
		Customer existing = customerService.getCustomerById(customer.getCustomerId());
		System.out.println(existing.getCustomerId());
		existing.setFirstName(customer.getFirstName());
		existing.setLastName(customer.getLastName());
		existing.setDob(customer.getDob());
		return ResponseEntity.ok(customerService.addCustomer(existing));
	}
}

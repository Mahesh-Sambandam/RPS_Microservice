package com.boa.kyc.repo;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.boa.kyc.model.Appointment;

public interface AppointmentRepo extends MongoRepository<Appointment, Integer> {

}
